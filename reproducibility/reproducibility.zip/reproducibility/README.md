# Reproducibility materials

This code base reproduces numerics and data reported in the following manuscript.

	A. J. Aw, ``Semi-regular admixed arrays: asymptotic enumeration and when information is additive.'' 


Use the table below to track the relevant numeric, data or figure reported.

| Manuscript item | Script (all also in `reproduce_paper.ipynb`) | What it checks |
|---|---|---|
| Example 2.1: \|A1\|, \|A2\|, \|S\|, \|A12\| | `text_values.py` | Exact counts from Eqs. (2.1)–(2.4); \|A12\| computed three independent ways |
| Introduction: 0.36 and 0.72 bits | `text_values.py` | 1/(4 ln 2) and 1/(2 ln 2) |
| Discussion: 5 × 10⁻¹¹ | `text_values.py` | 1/(2NP) at N = 10⁴, P = 10⁶ |
| Figure 3 (regions, curves, marked points) | `figure3/export3.py`, `figure3/make3.py` | Evaluates the entropy gap L, η, κ_η, φ and C_V from Section 4 and writes the TikZ figure |
| Figure 3 caption values (1.11, 0.79, 1.29, 6.94, e^{−1/4}) | `figure3/reproduce_fig3_caption.py` | Closed-form limits (Proposition 4.3, Corollaries 4.1 and 4.4) against finite-size κ_{N,P} from Theorem 3.4 via `zagar` |

Note that Figures 1 and 2 of the manuscript are schematic diagrams and contain no computed values, so we do not reproduce them here.

## Requirements

- Python ≥ 3.9 with `zagar` ≥ 0.2.0 (`pip install zagar`; building it needs the Boost headers, e.g. `apt-get install libboost-dev` or `brew install boost`), `numpy`, `scipy` and `matplotlib`.
- A LaTeX installation with `pgfplots` ≥ 1.18, to compile Figure 3.

## Run

**Notebook (recommended).** Open `reproduce_paper.ipynb` in Jupyter and run all cells. It explains each item with the relevant formula, shows Figure 3 inline and ends with a table of all checks. The copy here is saved with its outputs, so it can be read without running it.

**Command line.**

```
bash run_all.sh
```

This runs `text_values.py`, regenerates Figure 3 from scratch (data, TikZ code and PDF), and runs `reproduce_fig3_caption.py`. Each script prints the computed values next to the values in the manuscript and reports any mismatch. Total run time should take about a minute.

## Notes

- The Figure 3 caption points lie on the level set L = 0 at irrational densities, so the integer constraints 2Pā, 2Nf₀, 2Nf₁ cannot all hold there. `reproduce_fig3_caption.py` therefore evaluates the binomial coefficients in \|A1\|, \|A2\| and \|V\| with the Gamma function; it first checks that these agree with `zagar.getA1` and `zagar.getA2` at integer inputs. For Case 4 (rational densities) it also runs fully exactly with integer constraints.
- Figure 3 is compiled outside the manuscript, so its legend's reference to Corollary 4.4 is a fixed number set in `figure3/make3.py`. This can be updated if needed (e.g., if Section 4 is renumbered).
- Parts of this code were written with the assistance of an AI tool (Claude, Anthropic). The author has vetted the entire code base and takes full responsibility for any errors that remain.
