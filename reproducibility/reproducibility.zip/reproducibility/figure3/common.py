import numpy as np
from scipy.optimize import brentq
def H(*p):
    p=np.array(p,dtype=float); p=p[p>0]; return -(p*np.log2(p)).sum()
def h(x):
    x=np.clip(x,1e-300,1-1e-16); return -(x*np.log2(x)+(1-x)*np.log2(1-x))
def L_case1(a,f0,f1):
    """entropy gap in Case 1 when f0,f1<=1/2 (abar_V = 1/2)."""
    s=f0+f1; a0=(a-f1)/(1-s)
    return (1-h(a))-(1-s)*(1-h(a0))
def eta(a,f0,f1):
    p0=1-a-f0; pt=a-f1; return p0*pt/(a*(1-a)*(p0+pt))
phi=lambda x: h(x)-x
U_HALF=brentq(lambda u: phi(u)-0.5,0.01,1/3)
def case2_f0(a):
    """f0 on Case-2 face (f1=a) where heuristic holds; None if no solution."""
    if not (U_HALF<a<1/3): return None
    v=brentq(lambda v: phi(v)-phi(a),1/3,0.5-1e-12); return 1-v
