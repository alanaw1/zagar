#!/usr/bin/env python3
"""
Reproduce the numbers in the caption of Figure 3 (fig:kappa-surface), main_v8.

    kappa_{N,P} = |A12| * |V| / (|A1| * |A2|)

Two independent routes are compared for each caption value:

  (1) Closed form: the limit of kappa_{N,P} from Proposition 4.3 / Corollary 4.4
      (Cases 1-3) and Corollary 4.1 (Case 4).

  (2) Finite (N, P) with zagar: log2|A12| from zagar.log2_A12_asymptotic
      (Theorem 3.4), and the exact formulas for |A1|, |A2| (Proposition 2.3) and
      |V| (Section 4). kappa_{N,P} is computed for N = P growing and should
      converge to the limit in (1), with O(1/N) error.

Integrality. The Case-1 and Case-2 caption points lie on the level set L = 0 at
irrational densities, so 2P*abar, 2N*f0, 2N*f1 cannot all be integers. For
these points the binomial coefficients in |A1|, |A2| and |V| are evaluated with
the Gamma function (log-gamma), which agrees with zagar.getA1 / zagar.getA2 at
integer inputs; that agreement is checked first. Case 4 (rational densities)
is additionally run fully exactly with integer constraints via zagar.getA1 and
zagar.getA2.

Requires: zagar >= 0.2.0, numpy, scipy.
"""
import math

import numpy as np
from scipy.optimize import brentq
from scipy.stats import binom

import zagar

LN2 = math.log(2.0)


# ---------------------------------------------------------------- formulas ---
def h(x):
    """Binary entropy H(x, 1-x) in bits."""
    return -(x * math.log2(x) + (1 - x) * math.log2(1 - x))


def H(*p):
    """Shannon entropy in bits."""
    return -sum(q * math.log2(q) for q in p if q > 0)


def calH(a, f0, f1):
    """Entropy functional of Result 1.1 / Theorem 3.4 (four regimes)."""
    case = zagar.classify_case(a, f0, f1)
    if case == 1:
        return H(1 - a - f0, a - f1, f1, f0)
    if case == 2:
        return H(a, f0, 1 - a - f0)
    if case == 3:
        return H(1 - a, f1, a - f1)
    return H(a, 1 - a)


def a_V(f0, f1):
    """Point of [f1, 1-f0] closest to 1/2."""
    return min(max(0.5, f1), 1 - f0)


def L(a, f0, f1):
    """Entropy gap L(abar, f0, f1), Eq. defining L in Section 4."""
    s = f0 + f1
    return (calH(a, f0, f1) + h(a_V(f0, f1)) - h(a)
            - H(f0, f1, 1 - s) - (1 - s))


def eta(a, f0, f1):
    return (a - f1) * (1 - a - f0) / (a * (1 - a) * (1 - f0 - f1))


def kappa_eta(a, f0, f1):
    e = eta(a, f0, f1)
    return e ** -0.5 * math.exp(-(1 - e) / 4)


def C_V(f0, f1):
    aV = a_V(f0, f1)
    v = min(aV, 1 - aV)
    return (1 - v) / (1 - 2 * v) / math.sqrt(4 * math.pi * aV * (1 - aV))


def limit_closed_form(a, f0, f1):
    """Limit of kappa_{N,P} when L = 0 (Corollaries 4.1 and 4.4)."""
    case = zagar.classify_case(a, f0, f1)
    if case == 4:
        return math.exp(-0.25)
    if case == 1:
        k = kappa_eta(a, f0, f1)
        return k if (f0 < 0.5 and f1 < 0.5) else k / 2
    # Cases 2 and 3 with f0 > 1/2 or f1 > 1/2
    return math.exp(-0.25) * math.sqrt(4 * math.pi * a * (1 - a)) * C_V(f0, f1)


# ------------------------------------------- exact sizes, real arguments ---
def log2_binom(n, k):
    return (math.lgamma(n + 1) - math.lgamma(k + 1) - math.lgamma(n - k + 1)) / LN2


def log2_A1(N, P, a):
    """Proposition 2.3(1), semi-regular: 2^{2NP} * C(2P, 2Pa)^N."""
    return 2 * N * P + N * log2_binom(2 * P, 2 * P * a)


def log2_A2(N, P, f0, f1):
    """Proposition 2.3(2), semi-regular."""
    m = 2 * N * (f0 + f1)
    return P * (log2_binom(2 * N, m) + log2_binom(m, 2 * N * f1) + (2 * N - m))


def log2_V(N, P, a, f0, f1):
    """log2 |V|. Cases 1-3: 2^{2NP} * sum_{t=nA f1}^{nA(1-f0)} C(nA, t).
    Case 4: 2^{2NP} * C(nA, nA*a)."""
    nA = 2 * N * P
    if zagar.classify_case(a, f0, f1) == 4:
        return nA + log2_binom(nA, nA * a)
    lo, hi = nA * f1, nA * (1 - f0)
    if f1 <= 0.5 <= 1 - f0:
        # Mode inside the range: the sum is a central binomial probability.
        # Both endpoints are integers whenever they matter (f0 = 1/2 gives nA/2).
        S = binom.cdf(math.floor(hi + 1e-9), nA, 0.5) - binom.cdf(math.ceil(lo - 1e-9) - 1, nA, 0.5)
        return 2 * nA + math.log2(S)
    # Mode outside the range: geometric tail anchored at the endpoint nearest 1/2.
    anchor, step = (hi, -1) if 1 - f0 < 0.5 else (lo, +1)
    logs, j = [], 0
    while True:
        t = anchor + step * j
        if t < lo - 1e-9 or t > hi + 1e-9:
            break
        logs.append(log2_binom(nA, t))
        if j > 50 and logs[-1] < logs[0] - 80:   # remaining terms < 2^-80 relative
            break
        j += 1
    m = max(logs)
    return nA + m + math.log2(sum(2.0 ** (x - m) for x in logs))


def kappa_NP(N, P, a, f0, f1):
    """kappa_{N,P} with |A12| from zagar (Theorem 3.4)."""
    l12 = zagar.log2_A12_asymptotic(N, P, a, f0, f1)
    return 2.0 ** (l12 + log2_V(N, P, a, f0, f1) - log2_A1(N, P, a) - log2_A2(N, P, f0, f1))


# ----------------------------------------------------------------- checks ---
def check_real_argument_formulas():
    """The log-gamma formulas must agree with zagar's exact integer counts."""
    for N, P, a1, p0, p1 in [(3, 4, 6, 2, 1), (20, 25, 15, 9, 12), (40, 40, 32, 30, 11)]:
        a, f0, f1 = a1 / (2 * P), p0 / (2 * N), p1 / (2 * N)
        e1 = zagar.getA1(N, P, [a1] * N, return_log=True)
        e2 = zagar.getA2(N, P, [p0] * P, [p1] * P, return_log=True)
        assert abs(e1 - log2_A1(N, P, a)) < 1e-6 * max(1, e1), (e1, log2_A1(N, P, a))
        assert abs(e2 - log2_A2(N, P, f0, f1)) < 1e-6 * max(1, e2), (e2, log2_A2(N, P, f0, f1))
    print("Gamma-function |A1|, |A2| agree with zagar.getA1 / zagar.getA2 at integer inputs.\n")


def solve(f, lo, hi):
    return brentq(f, lo, hi, xtol=1e-15, rtol=4 * np.finfo(float).eps, maxiter=500)


def caption_points():
    pts = []
    # (a) Case 1 on L = 0: abar = 0.3, f1 = 0.1   -> caption: 1.11 at f0 ~ 0.157
    f0 = solve(lambda x: L(0.3, x, 0.1), 0.1, 0.3)
    pts.append(("(a) Case 1, L=0", (0.3, f0, 0.1), "1.11"))
    # (b) L = 0 meets the plane f0 = 1/2 at abar = 0.4 -> caption: 0.79 and 1.29
    g = lambda f1: L(0.4, 0.5, f1)
    xs = np.linspace(1e-6, 0.4 - 1e-6, 4001)
    ys = [g(x) for x in xs]
    roots = [solve(g, xs[i], xs[i + 1]) for i in range(len(xs) - 1) if ys[i] * ys[i + 1] < 0]
    for r, cap in zip(sorted(roots), ["0.79", "1.29"]):
        pts.append(("(b) Case 1, f0=1/2", (0.4, 0.5, r), cap))
    # (d) Case 2 face f1 = abar = 0.2, phi(abar) = phi(1-f0) -> caption: 6.94 at f0 ~ 0.524
    phi = lambda x: h(x) - x
    v = solve(lambda x: phi(x) - phi(0.2), 1 / 3, 0.5 - 1e-12)
    pts.append(("(d) Case 2, L=0", (0.2, 1 - v, 0.2), "6.94"))
    # Purple: Case 4 edge abar = f1 = 1 - f0      -> caption: e^{-1/4} = 0.78
    for a in (0.3, 0.4, 0.5):
        pts.append(("Case 4 edge", (a, 1 - a, a), "e^{-1/4}"))
    return pts


def main():
    check_real_argument_formulas()
    sizes = [50, 200, 800, 3200]
    print(f"{'point':<20}{'(abar, f0, f1)':<28}{'L':>10}  "
          + "".join(f"{'N=P=' + str(n):>12}" for n in sizes)
          + f"{'limit':>10}{'caption':>10}")
    ok = True
    for name, (a, f0, f1), cap in caption_points():
        lim = limit_closed_form(a, f0, f1)
        ks = [kappa_NP(n, n, a, f0, f1) for n in sizes]
        cap_val = math.exp(-0.25) if cap == "e^{-1/4}" else float(cap)
        good = round(lim, 2) == round(cap_val, 2) and abs(ks[-1] - lim) < 5e-3 * lim
        ok &= good
        print(f"{name:<20}({a:.4f}, {f0:.5f}, {f1:.5f})  {L(a, f0, f1):>10.1e}  "
              + "".join(f"{k:>12.5f}" for k in ks)
              + f"{lim:>10.5f}{cap:>10}" + ("" if good else "   <-- MISMATCH"))

    # Case 4, fully exact integer constraints (no Gamma-function extension)
    print("\nCase 4, exact integer constraints via zagar.getA1 / zagar.getA2:")
    for a in (0.3, 0.4, 0.5):
        row = []
        for n in (50, 200, 800):
            N = P = n
            ka, kf = round(2 * P * a), round(2 * N * a)
            l1 = zagar.getA1(N, P, [ka] * N, return_log=True)
            l2 = zagar.getA2(N, P, [2 * N - kf] * P, [kf] * P, return_log=True)
            lv = 2 * N * P + log2_binom(2 * N * P, 2 * N * P * a)
            l12 = zagar.log2_A12_asymptotic(N, P, a, 1 - a, a)
            row.append(2.0 ** (l12 + lv - l1 - l2))
        print(f"  abar={a}: " + "  ".join(f"N=P={n}: {k:.5f}" for n, k in zip((50, 200, 800), row))
              + f"   e^(-1/4) = {math.exp(-0.25):.5f}")

    print("\nAll caption values reproduced." if ok else "\nSome caption values did NOT match.")


if __name__ == "__main__":
    main()
