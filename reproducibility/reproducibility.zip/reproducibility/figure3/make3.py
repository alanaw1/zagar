import json
m=json.load(open('tikz3/meta.json'))
col={1:'black',2:'caseTwo',3:'caseThree',4:'caseFour'}
L=[r"""% Where the independence heuristic holds (Section 4).
% Panels (a)-(c): slices at abar = 0.3, 0.4, 0.5 in the (f0,f1) plane. Panel (d): the Case 2 face f1 = abar in the (abar,f0) plane.
% Requires: \usepackage{pgfplots}\pgfplotsset{compat=1.18}\usepgfplotslibrary{groupplots}\usetikzlibrary{calc}
% Data files (data/*.dat) are produced by export3.py.
\definecolor{caseTwo}{HTML}{EB6834}
\definecolor{caseThree}{HTML}{1F9E89}
\definecolor{caseFour}{HTML}{8C5CC7}
\definecolor{posFill}{HTML}{F3C6C0}
\definecolor{negFill}{HTML}{D3E3F8}
\definecolor{outFill}{HTML}{E2E2DC}
\begin{tikzpicture}[
  up/.style={mark=triangle*,mark size=2.3pt,mark options={draw=black,line width=0.4pt,fill=#1}},
  dn/.style={mark=triangle*,mark size=2.3pt,mark options={rotate=180,draw=black,line width=0.4pt,fill=#1}},
  lab/.style={font=\tiny,inner sep=1pt},
  panel/.style={font=\small\bfseries,anchor=south west,inner sep=0pt}]
\pgfplotsset{every axis/.append style={
  width=3.55cm, height=3.55cm, xmin=0, xmax=1, ymin=0, ymax=1, axis equal image,
  xtick={0,0.5,1}, ytick={0,0.5,1}, xticklabels={$0$,$\tfrac12$,$1$}, yticklabels={$0$,$\tfrac12$,$1$},
  tick label style={font=\scriptsize}, label style={font=\small}, title style={font=\small, yshift=-3pt},
  axis lines=left, axis line style={line width=0.4pt}, tick style={line width=0.4pt},
  xlabel style={yshift=5pt}, ylabel style={yshift=-4pt}, clip=false}}
\begin{groupplot}[group style={group size=3 by 1, horizontal sep=0.45cm, y descriptions at=edge left},
  xlabel={$f_0$}, ylabel={$f_1$}]"""]
for i,tag in enumerate(['30','40','50']):
    d=m[tag]; a=d['a']; f0m=d['f0max']; f1m=d['f1max']; X0=d['X0']; X1=d['X1']
    L.append(r"\nextgroupplot[title={(%s)\ $\overline{a}=%.1f$}]"%('abc'[i],a))
    L.append(r"\fill[negFill] (axis cs:0,0) rectangle (axis cs:%.4f,%.4f);"%(X0,X1))
    if d['npos']>0: L.append(r"\addplot[fill=posFill, draw=none, forget plot] table {data/pos_%s.dat};"%tag)
    if f0m>0.5: L.append(r"\fill[outFill] (axis cs:0.5,0) rectangle (axis cs:%.4f,%.4f);"%(f0m,f1m))
    if f1m>0.5: L.append(r"\fill[outFill] (axis cs:0,0.5) rectangle (axis cs:%.4f,%.4f);"%(f0m,f1m))
    if f0m>0.5: L.append(r"\draw[densely dashed, black!45, line width=0.4pt] (axis cs:0.5,0) -- (axis cs:0.5,%.4f);"%f1m)
    L.append(r"\addplot[black, line width=1.1pt, forget plot] table {data/zero_%s.dat};"%tag)
    L.append(r"\draw[black!70, line width=0.3pt] (axis cs:0,0) rectangle (axis cs:%.4f,%.4f);"%(f0m,f1m))
    L.append(r"\draw[caseTwo, line width=2pt] (axis cs:0,%.4f) -- (axis cs:%.4f,%.4f);"%(f1m,f0m,f1m))
    L.append(r"\draw[caseThree, line width=2pt] (axis cs:%.4f,0) -- (axis cs:%.4f,%.4f);"%(f0m,f0m,f1m))
    for x,y,k,case,lab,anc in d['marks']:
        L.append(r"\addplot[only marks,%s=%s,forget plot] coordinates {(%.4f,%.4f)};"%('up' if k>1 else 'dn',col[case],x,y))
        if lab and tag=='40':
            ly={0.19:0.10,0.37:0.27}[round(y,2)]
            L.append(r"\draw[black!55, line width=0.3pt] (axis cs:%.4f,%.4f) -- (axis cs:0.70,%.3f) node[lab,anchor=west,text=black] {%s};"%(x,y,ly,lab))
        elif lab:
            sh={'north west':'xshift=1pt,yshift=-1pt','east':'xshift=-3pt','south west':'xshift=1pt,yshift=1pt'}[anc]
            L.append(r"\node[lab,anchor=%s,%s] at (axis cs:%.4f,%.4f) {%s};"%(anc,sh,x,y,lab))
L.append(r"\end{groupplot}")
ex=m['face']['ex']
L.append(r"""\begin{axis}[at={($(group c3r1.south east)+(1.45cm,0)$)}, anchor=south west,
  title={(d)\ Case~2 face $f_1=\overline{a}$}, xlabel={$\overline{a}$}, ylabel={$f_0$}]
\fill[outFill] (axis cs:0,0) -- (axis cs:1,0) -- (axis cs:0.5,0.5) -- (axis cs:0,0.5) -- cycle;
\fill[negFill] (axis cs:0,0.5) -- (axis cs:0.5,0.5) -- (axis cs:0,1) -- cycle;
\addplot[fill=posFill, draw=none, forget plot] table {data/face_pos.dat};
\draw[densely dashed, black!45, line width=0.4pt] (axis cs:0,0.5) -- (axis cs:0.5,0.5);
\draw[black!70, line width=0.3pt] (axis cs:0,0) -- (axis cs:1,0);
\draw[black!70, line width=0.3pt] (axis cs:0,0) -- (axis cs:0,1);
\draw[caseFour, line width=2pt] (axis cs:0,1) -- (axis cs:1,0);
\addplot[caseTwo, line width=1.6pt, forget plot] table {data/face_curve.dat};
\addplot[only marks,up=caseTwo,forget plot] coordinates {(%.4f,%.4f)};
\node[lab,anchor=south east,xshift=-1pt,yshift=1pt] at (axis cs:%.4f,%.4f) {%.2f};
\addplot[only marks,dn=caseFour,forget plot] coordinates {(0.3333,0.6667)};
\end{axis}"""%(ex[0],ex[1],ex[0],ex[1],ex[2]))
L.append(r"""\node[anchor=north, font=\scriptsize, inner sep=0pt] at ($(group c2r1.outer south)!0.5!(current axis.outer south)+(0,-0.05cm)$) {%
\def\sw#1{\tikz[baseline=-0.6ex]{\fill[#1] (0,-0.75ex) rectangle (1.6em,0.75ex);}}%
\def\ln#1#2{\tikz[baseline=-0.6ex]{\draw[#1, line width=#2] (0,0) -- (1.6em,0);}}%
\def\tri#1#2{\tikz[baseline={([yshift=-0.55ex]current bounding box.center)}]{\filldraw[fill=#1,draw=black,line width=0.4pt,rotate=#2] (90:3.3pt)--(210:3.3pt)--(330:3.3pt)--cycle;}}%
\setlength{\tabcolsep}{2pt}\renewcommand{\arraystretch}{1.25}%
\begin{tabular}{@{}cl@{\hspace{14pt}}cl@{}}
\sw{posFill} & $\mathcal{L}>0$: $\kappa_{N,P}\to\infty$ &
\sw{negFill} & $\mathcal{L}<0$: $\kappa_{N,P}\to0$ \\
\sw{outFill} & $\kappa_{N,P}\to0$ or $\infty$ (lower-order terms; Corollary~\ref{cor:surface}) &
\ln{black}{1.1pt} & $\mathcal{L}=0$, Case 1 with $f_0,f_1<\tfrac12$: $\kappa_{N,P}\to\kappa_\eta>1$ \\
\ln{caseTwo}{2pt}\,\ln{caseThree}{2pt} & Case 2 face $f_1=\overline a$; Case 3 face $f_0=1-\overline a$ &
\ln{caseTwo}{1.6pt} & $\mathcal{L}=0$ in Case 2 (panel d): finite limit \\
\ln{caseFour}{2pt} & Case 4 edge $\overline a=f_1=1-f_0$: $\kappa_{N,P}\to e^{-1/4}$ &
\tri{white}{0}\,\tri{white}{180} & finite limit $>1$ (undercounts) / $<1$ (overcounts)
\end{tabular}};
\end{tikzpicture}""")
open('tikz3/fig_kappa_region_body.tex','w').write('\n'.join(L)+'\n')
open('tikz3/fig_kappa_region.tex','w').write(r"""\documentclass[border=3pt]{standalone}
\usepackage{amsmath,amssymb}
\usepackage{pgfplots}
\pgfplotsset{compat=1.18}
\usepgfplotslibrary{groupplots}
\usetikzlibrary{calc}
\renewcommand{\ref}[1]{4.4}% standalone build: cor:surface is Corollary 4.4 in main_v8; update if numbering changes
\begin{document}
\input{fig_kappa_region_body}
\end{document}
""")
