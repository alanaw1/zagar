Figure 3 (fig_kappa_region) -- "Where the independence heuristic holds"

Contents
  common.py    Analytical formulas: entropy gap L (Case 1, f0,f1 <= 1/2), eta,
               phi(x) = H(x,1-x) - x, and the Case-2 curve phi(abar) = phi(1-f0).
  export3.py   Evaluates the formulas; writes tikz3/data/*.dat and tikz3/meta.json.
  make3.py     Writes the TikZ/pgfplots code tikz3/fig_kappa_region_body.tex and the
               standalone wrapper tikz3/fig_kappa_region.tex.
  tikz3/       All generated outputs, including the compiled fig_kappa_region.pdf.

Reproduce (run from this folder; requires Python 3 with numpy, scipy, matplotlib,
and a LaTeX installation with pgfplots >= 1.18)
  python3 export3.py
  python3 make3.py
  cd tikz3 && pdflatex fig_kappa_region.tex

Note: the standalone wrapper replaces \ref with a fixed number because the figure is
compiled outside the paper. It is set to 4.4 (label cor:surface in main_v8). If the
numbering of Section 4 changes, update the \renewcommand{\ref} line in make3.py.

Caption values
  reproduce_fig3_caption.py   Reproduces the numbers in the caption of Figure 3 (requires zagar >= 0.2.0).
