import numpy as np, matplotlib, os, json
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from scipy.optimize import brentq
from common import *
out='tikz3/data'
def kap_eta(a,f0,f1): e=eta(a,f0,f1); return e**-0.5*np.exp(-(1-e)/4)
def CV(v): return (1-v)/(1-2*v)/np.sqrt(4*np.pi*v*(1-v))
def write(fn,segs):
    with open(os.path.join(out,fn),'w') as f:
        for k,seg in enumerate(segs):
            if k: f.write('\n')
            for x,y in seg: f.write('%.5f %.5f\n'%(x,y))
meta={}
for tag,a in [('30',0.3),('40',0.4),('50',0.5)]:
    f0m,f1m=1-a,a; X0,X1=min(.5,f0m),min(.5,f1m)
    g0=np.linspace(1e-5,X0-1e-6,900); g1=np.linspace(1e-5,X1-1e-6,900); F0,F1=np.meshgrid(g0,g1); Z=L_case1(a,F0,F1)
    if tag=='50': zero=[[(0,0),(.5,.5)]]; pos=[]
    else:
        fig,ax=plt.subplots(); cs=ax.contour(F0,F1,Z,levels=[0]); zero=[p for p in cs.allsegs[0] if len(p)>2]
        cf=ax.contourf(F0,F1,Z,levels=[0,np.inf]); pos=[poly for path in cf.get_paths() for poly in path.to_polygons(closed_only=True)]; plt.close(fig)
    zero=[p[::3] if len(p)>60 else p for p in zero]; pos=[p[::3] for p in pos]
    write('zero_%s.dat'%tag,zero); write('pos_%s.dat'%tag,pos)
    marks=[]
    if tag=='30':
        f0=brentq(lambda x:L_case1(.3,x,.1),.1,.3); marks.append((f0,.1,kap_eta(.3,f0,.1),1,'1.11','north west'))
    if tag=='40':
        g=lambda f1: L_case1(a,.5,f1); xs=np.linspace(1e-9,a-1e-9,40001); ys=g(xs)
        for i in np.where(np.sign(ys[:-1])!=np.sign(ys[1:]))[0]:
            r=brentq(g,xs[i],xs[i+1]); k=kap_eta(a,.5,r)/2
            marks.append((.5,r,k,1,'%.2f'%k,'east'))
    marks.append((f0m,f1m,np.exp(-.25),4,'$e^{-1/4}$' if tag=='50' else '','south west'))
    meta[tag]=dict(a=a,f0max=f0m,f1max=f1m,X0=X0,X1=X1,npos=len(pos),marks=marks)
    print(tag,[(round(m[0],4),round(m[1],4),round(m[2],3),m[4]) for m in marks])
# Case 2 face: x = abar, y = f0, region abar + f0 <= 1 ; in f0>1/2: L = phi(1-f0) - phi(abar)
A=np.linspace(1e-5,0.5-1e-6,900); F=np.linspace(0.5+1e-6,1-1e-5,900); AA,FF=np.meshgrid(A,F)
LL=np.where(AA+FF<1, phi(1-FF)-phi(AA), np.nan)
fig,ax=plt.subplots(); cf=ax.contourf(AA,FF,LL,levels=[0,np.inf]); pos=[poly for path in cf.get_paths() for poly in path.to_polygons(closed_only=True)]; plt.close(fig)
write('face_pos.dat',[p[::3] for p in pos])
aa=np.linspace(U_HALF+1e-9,1/3-1e-9,200); curve=[(x,case2_f0(x)) for x in aa]; curve=[(U_HALF,.5)]+curve+[(1/3,2/3)]
write('face_curve.dat',[curve])
k=np.exp(-.25)*np.sqrt(4*np.pi*.2*.8)*CV(1-case2_f0(.2))
meta['face']=dict(ex=(0.2,case2_f0(0.2),k))
print('face example',meta['face'], 'U_HALF',U_HALF)
json.dump(meta,open('tikz3/meta.json','w'),indent=1)
