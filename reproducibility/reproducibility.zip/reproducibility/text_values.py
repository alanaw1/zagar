#!/usr/bin/env python3
"""
Reproduce the numerical values stated in the text of the manuscript
("Semi-regular admixed arrays: asymptotic enumeration and when information is
additive", A. J. Aw).

  * Example 2.1 / Proposition 2.3: |A1|, |A2|, |S| and |A12| for
    N = 3, P = 4, a = (6,1,7), phi0 = (2,0,2,1), phi1 = (1,3,4,1).
  * Introduction: 1/(4 ln 2) ~ 0.36 bits and 1/(2 ln 2) ~ 0.72 bits.
  * Discussion: 1/(2NP) = 5e-11 for N = 1e4 individuals and P = 1e6 loci.

|A12| is computed three independent ways: the two exact algorithms in zagar
(dynamic programming over loci; enumeration over column sums), and a direct
evaluation of Eq. (2.3) written here from the formula in the paper, which uses
zagar only to count binary matrices with given margins.

Requires: zagar >= 0.2.0. Run: python3 text_values.py
"""
import itertools
import math

import zagar

ok = True


def check(label, got, expected):
    global ok
    good = got == expected
    ok &= good
    print(f"  {label:<44} {got!s:>16}   paper: {expected!s:<16} {'OK' if good else 'MISMATCH'}")


# ------------------------------------------------------------ Example 2.1 ---
N, P = 3, 4
a = [6, 1, 7]
phi0 = [2, 0, 2, 1]
phi1 = [1, 3, 4, 1]
print(f"Example 2.1: N={N}, P={P}, a={a}, phi0={phi0}, phi1={phi1}")

# |A1|, Eq. (2.1): 2^{2NP} prod_n C(2P, a_n)
A1_formula = 2 ** (2 * N * P) * math.prod(math.comb(2 * P, x) for x in a)
check("|A1|  (Eq. 2.1, direct)", A1_formula, 30_064_771_072)
check("|A1|  (zagar.getA1)", int(zagar.getA1(N, P, a)), 30_064_771_072)

# |A2|, Eq. (2.2): prod_p C(2N, s_p) C(s_p, phi1_p) 2^{2N - s_p}, s_p = phi0_p + phi1_p
A2_formula = math.prod(
    math.comb(2 * N, p0 + p1) * math.comb(p0 + p1, p1) * 2 ** (2 * N - p0 - p1)
    for p0, p1 in zip(phi0, phi1))
check("|A2|  (Eq. 2.2, direct)", A2_formula, 552_960_000)
check("|A2|  (zagar.getA2)", int(zagar.getA2(N, P, phi0, phi1)), 552_960_000)

# Feasible set S, Eq. (2.4): (v1, v2) in {0..N}^{2P}, phi1 <= v1 + v2 <= 2N - phi0, locuswise
per_locus = [[(x, y) for x in range(N + 1) for y in range(N + 1) if p1 <= x + y <= 2 * N - p0]
             for p0, p1 in zip(phi0, phi1)]
check("|S|   (Eq. 2.4)", math.prod(len(c) for c in per_locus), 5_040)

# |A12|, Eq. (2.3): sum over S of |A(s1, s2, a)| * prod_p C(s1p+s2p, phi1p) C(2N-s1p-s2p, phi0p)
A12_eq23 = 0
for choice in itertools.product(*per_locus):
    s1 = [c[0] for c in choice]
    s2 = [c[1] for c in choice]
    weight = math.prod(math.comb(x + y, p1) * math.comb(2 * N - x - y, p0)
                       for (x, y), p0, p1 in zip(choice, phi0, phi1))
    if weight:
        A12_eq23 += weight * zagar.count_matrices(a, s1 + s2)
check("|A12| (Eq. 2.3, direct sum over S)", A12_eq23, 133_520)
check("|A12| (zagar, dynamic programming)", int(zagar.count_A12(N, a, phi0, phi1, method="dp")), 133_520)
check("|A12| (zagar, column-sum enumeration)", int(zagar.count_A12(N, a, phi0, phi1, method="column-sums")), 133_520)

# ----------------------------------------------------------- Introduction ---
print("\nIntroduction: information carried by the e^{-1/4} and e^{-1/2} correction factors")
check("1/(4 ln 2) bits, 2 d.p.", f"{1 / (4 * math.log(2)):.2f}", "0.36")
check("1/(2 ln 2) bits, 2 d.p.", f"{1 / (2 * math.log(2)):.2f}", "0.72")

# ------------------------------------------------------------- Discussion ---
print("\nDiscussion: additivity threshold |L| < 1/(2NP) at biobank scale")
check("1/(2NP), N=1e4, P=1e6", 1 / (2 * 10**4 * 10**6), 5e-11)

print("\nAll values reproduced." if ok else "\nSome values did NOT match.")
