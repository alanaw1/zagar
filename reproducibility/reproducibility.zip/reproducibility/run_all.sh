#!/usr/bin/env bash
# Regenerate every computed value and data figure in the manuscript.
set -euo pipefail
cd "$(dirname "$0")"
echo "=== Values in the text ==="
python3 text_values.py
echo
echo "=== Figure 3: data, TikZ code and PDF ==="
cd figure3
python3 export3.py
python3 make3.py
(cd tikz3 && pdflatex -interaction=nonstopmode fig_kappa_region.tex > /dev/null && echo "Wrote figure3/tikz3/fig_kappa_region.pdf")
echo
echo "=== Figure 3 caption values ==="
python3 reproduce_fig3_caption.py
